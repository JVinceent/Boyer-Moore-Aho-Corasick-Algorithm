# =============================================================================
# normalizer.py
# Hybrid Toxic Language Detection Pipeline
# Component 1 — Leetspeak Normalizer
# =============================================================================
# Converts leetspeak-obfuscated characters into their standard plain text
# equivalents before pattern matching begins. This is a prerequisite step —
# without normalization, Boyer-Moore and Aho-Corasick cannot match obfuscated
# toxic terms since both algorithms operate on exact character sequences.
#
# Design Decisions:
#   - Case-insensitive: input is lowercased before substitution.
#   - Longest-Match-First: Multi-character symbols (like '()') are replaced 
#     before single-character symbols (like '(') to prevent partial replacements.
#   - Punctuation Stripping: Removes trailing symbols after normalization.
# =============================================================================

import re

# -----------------------------------------------------------------------------
# LEETSPEAK SUBSTITUTION MAP
# Derived from the predefined substitution table in the study.
# -----------------------------------------------------------------------------
LEET_MAP =  {
    # Numbers
    '0': 'o',
    '1': 'i',  # Note: '1' is sometimes 'l', but 'i' is more common in toxic words
    '2': 'z',
    '3': 'e',
    '4': 'a',
    '5': 's',
    '6': 'g',
    '7': 't',
    '8': 'b',
    '9': 'g',
    
    # Special Characters (Single)
    '@': 'a',
    '$': 's',
    '!': 'i',
    '+': 't',
    '<': 'c',
    '(': 'c',
    '[': 'c',
    '{': 'c',
    '|': 'i',
    
    # Special Characters (Multi-character)
    '()': 'o',
    '[]': 'o',
    '{}': 'o',
    '\\/': 'v',
    '/\\': 'a'
}

# Pre-sort keys by length (longest first) so '()' is evaluated before '('
SORTED_LEET_KEYS = sorted(LEET_MAP.keys(), key=len, reverse=True)


# -----------------------------------------------------------------------------
# CORE FUNCTION
# -----------------------------------------------------------------------------
def normalize(message: str) -> str:
    """
    Normalizes a raw chat message by:
      1. Converting the message to lowercase
      2. Replacing leetspeak symbols (longest symbols first)
      3. Stripping leftover punctuation for clean pattern matching

    Parameters:
        message (str): Raw chat message as typed by the player

    Returns:
        str: Normalized plain text message ready for pattern matching
    """
    if not message or not isinstance(message, str):
        return ""

    # Step 1 — Lowercase entire message for case-insensitive matching
    message = message.lower()

    # Step 2 — Find and replace using the sorted map
    for leet_char in SORTED_LEET_KEYS:
        message = message.replace(leet_char, LEET_MAP[leet_char])

    # Step 3 — Clean up remaining non-alphabetic characters
    # (Keeps only standard a-z alphabet and spaces)
    message = re.sub(r'[^a-z\s]', '', message)
    message = re.sub(r'\s+', ' ', message).strip()

    return message


# -----------------------------------------------------------------------------
# BATCH FUNCTION
# Normalizes a list of messages at once. Used by benchmark.py.
# -----------------------------------------------------------------------------
def normalize_batch(messages: list) -> list:
    """
    Normalizes a list of raw chat messages.
    """
    return [normalize(msg) for msg in messages]


# =============================================================================
# QUICK TEST — run this file directly to verify normalizer is working
# =============================================================================
if __name__ == "__main__":

    test_inputs = [
        # (raw_input, expected_output)
        ("g4g0",                "gago"),
        ("b0b0",                "bobo"),
        ("74ng4",               "tanga"),
        ("1d107",               "idiot"),
        ("$7up1d",              "stupid"),
        ("ul0l",                "ulol"),
        ("74ng1n4",             "tangina"),
        ("9490",                "gago"),
        ("8080",                "bobo"),
        ("74n94",               "tanga"),
        ("ang g4g0 mo pre!",    "ang gago mo pre"), # Tests punctuation removal
        ("pre ang b0b0 mo",     "pre ang bobo mo"),
        ("GAGO",                "gago"),       # case insensitive
        ("G4G0",                "gago"),       # leet + uppercase
        ("b()b()",              "bobo"),       # multi-character leet
        ("b[0]b[0]",            "bobo"),       # mixed leet
        ("good game everyone",  "good game everyone"),  # clean — no change
        ("",                    ""),           # empty string
    ]

    print("=" * 65)
    print("NORMALIZER TEST RESULTS")
    print("=" * 65)
    print(f"{'Input':<25} | {'Expected':<20} | {'Result':<20} | {'Pass'}")
    print("-" * 65)

    all_passed = True
    for raw, expected in test_inputs:
        result = normalize(raw)
        passed = result == expected
        if not passed:
            all_passed = False
        status = "✅" if passed else "❌"
        print(f"{raw:<25} | {expected:<20} | {result:<20} | {status}")

    print("-" * 65)
    if all_passed:
        print("✅ All tests passed! Normalizer is ready for the Hybrid Pipeline.")
    else:
        print("❌ Some tests failed. Review the substitution map.")
    print("=" * 65)